// src/auth/useAuth.js
import { useAuth } from './AuthContext';

export default useAuth;